/*
 * COMP603/03 Project 2, Group 6. Marina Newman 14873443 and Erin Thomas 21145466
 */

package p06_14873443_21145466;

import java.util.Scanner;
import java.sql.*;

public class MainMethod {

    public static void main(String[] args) throws SQLException {
        Scanner scan = new Scanner(System.in);

        //Start database connection
        try (Connection connection = DriverManager.getConnection("jdbc:derby:booking_boss;create=true")) {

            ShowDetails showDetails = new ShowDetails(connection);
            showDetails.createShowTable(connection); //Create the shows table
            showDetails.populateShowsTable(); //Populate the shows table

            UserDetails userDetails = new UserDetails();
            userDetails.createUserTable(connection); //Create the user table
            userDetails.retrieveUsers(connection); //Retrieves users from DB
            
            LogInAndRegisterJFrame login = new LogInAndRegisterJFrame(showDetails, userDetails);
            login.setVisible(true);
        } catch (SQLException e) {
            System.out.println("An error occurred while connecting to the database: " + e.getMessage());
        }
    }
}