/*
 * COMP603/03 Project 2, Group 6. Marina Newman 14873443 and Erin Thomas
 */

package p06_14873443_21145466;

import java.sql.*;
import java.util.HashMap;

public class UserDetails {

    private HashMap<String, User> storeUsers;

    public UserDetails() {
        this.storeUsers = new HashMap<>();
    }

    /* createUserTable method:
     * Creates a new table in the database to store a user - username, password,
     * and a history field for past bookings.
     */
    public void createUserTable(Connection connection) {
        try (Statement statement = connection.createStatement()) {
            connection.setAutoCommit(true); //Start connection

            //Check if the users table exists
            ResultSet usersTableResult = connection.getMetaData().getTables(null, null, "users", null);
            boolean usersTableExists = usersTableResult.next();

            if (!usersTableExists) { //If users table doesn't exist, create it
                statement.executeUpdate("CREATE TABLE users ("
                        + "id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY, "
                        + "username VARCHAR(255) UNIQUE NOT NULL, "
                        + "password VARCHAR(255) NOT NULL, "
                        + "history VARCHAR(255) DEFAULT NULL)"
                );

                //Test users
                statement.executeUpdate("INSERT INTO users (username, password, history) VALUES ('user1', 'pass1', 'Cats')");
                statement.executeUpdate("INSERT INTO users (username, password, history) VALUES ('user2', 'pass2', 'Evita')");

                System.out.println("Users table created successfully.");
            } else {
                    System.out.println("Users table already exists.");
                }
            

        } catch (SQLException e) {
            System.out.println("Creating database tables: " + e.getMessage());
        }
    }
    
    /* login method:
     * Checks the username and password against details stored in the database.
     * Returns true if passwords match, false if not matching.
     */
    public boolean login(Connection connection, String username, String password) {
        boolean matching = false;

        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM users WHERE username = ?")) {
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String storedPassword = resultSet.getString("password");
                if (storedPassword.equals(password)) {
                    matching = true;
                } else {
                    System.out.println("Uh oh, incorrect password :(\n");
                }
            } else {
                System.out.println("Uh oh, username or password is incorrect.\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return matching;
    }

    /* register method:
     * Takes in username and password to create a new user entry in the users table.
     */
    public boolean register(Connection connection, String username, String password) {
        boolean match = false;

        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO users (username, password, history) VALUES (?, ?, ?)")) {
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setNull(3, Types.VARCHAR); //Sets history to null
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                storeUsers.put(username, new User(username, password));
                match = true;
            }
        } catch (SQLException e) {
            System.out.println("\nError! This user already exists. Login or register a new user." + e.getMessage());
        }

        return match;
    }

    /* retrieveUsers method:
     * Retrieves information from the user table to populate the storeUsers hashmap.
     */
    public void retrieveUsers(Connection connection) {
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM users");

            while (resultSet.next()) {
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String history = resultSet.getString("history");
                storeUsers.put(username, new User(username, password));
            }
        } catch (SQLException e) {
            System.out.println("Error occurred while retrieving users: " + e.getMessage());
        }
    }

    /* printHistory method:
     * Retrieves user's history from database, uses a StringBuilder to create a string to return.
    */
    public String printHistory(Connection connection, String username) throws SQLException {
        StringBuilder historyBuilder = new StringBuilder();

        try (PreparedStatement statement = connection.prepareStatement("SELECT history FROM users WHERE username = ?")) {
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String history = resultSet.getString(1);
                if (history != null && !history.isEmpty()) {
                    historyBuilder.append(history);
                    historyBuilder.append("\n");
                } else {
                    historyBuilder.append("No history found for user ").append(username);
                }
            } else {
                historyBuilder.append("User not found: ").append(username);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return historyBuilder.toString();
    }

    /* saveHistory method:
     * Updates user's history field in the users table by appending the show name.
     */
    public void saveHistory(Connection connection, String username, String showName) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE users SET history = CASE WHEN history IS NULL THEN ? ELSE history || ? END WHERE username = ?")) { //Concat with ||
            statement.setString(1, showName + "\n");
            statement.setString(2, showName + "\n");
            statement.setString(3, username);
            statement.executeUpdate();

            User user = storeUsers.get(username);
            if (user != null) {
                Show addShow = new Show();
                addShow.setName(showName);
                user.bookShow(addShow);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //toString:
    @Override
    public String toString() {
        return "UserDetails{" + "storeUsers=" + storeUsers + '}';
    }
}