/*
 * COMP603/03 Project 2, Group 6. Marina Newman 14873443 and Erin Thomas
 */

package p06_14873443_21145466;

public class GoldTicket extends Ticket
{
    public GoldTicket(int row)
    {
        super(row);
    }

    @Override
    public double calcPrice(int row)
    {
        price = (10 - row) * 26;

        return price;
    }
}